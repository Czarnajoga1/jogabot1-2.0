module.exports = () => {
    user_id: {
        _id: {
            warns: Number
        }
    }
}